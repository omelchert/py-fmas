"""
py-fmas version information.

.. moduleauthor: Oliver Melchert <melchert@iqo.uni-hannover.de>
"""
__version__ = "1.3.0"
