"""
py-fmas version information.

.. moduleauthor: Oliver Melchert <melchert@iqo.uni-hannover.de>
"""
__version__ = "1.3.1"

"""
CHANGELOG:

1.3.1 (Mo 12 Apr 2021 09:31:30 CEST)
------------------------------------
* added CQE_RK$IP to py-fmas solver module - OM

"""
