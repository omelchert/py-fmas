"""py-fmas initialization

.. moduleauthor: Oliver Melchert <melchert@iqo.uni-hannover.de>
"""
from .app import run
